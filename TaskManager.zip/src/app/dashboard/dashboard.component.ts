import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor() { }
Designation:string;
Username:string;
NoOfTeamMembers:number;
TotalCostOfAllProjects:number;
PendingTasks:number;
UpComingProjects:number;
ProjectCost:number;

CurrentExpenditure:number;
AvailableFunds:number;
  ngOnInit() {
    this.Designation = "Team Leader";
    this.Username= "Kamran Khan";
    this.NoOfTeamMembers= 67;
    this.TotalCostOfAllProjects = 900;
    this.PendingTasks = 15;
    this.UpComingProjects= 2;
    this.ProjectCost = 23212;
    this.CurrentExpenditure=7832329;
    this.AvailableFunds=4;
  }

}
